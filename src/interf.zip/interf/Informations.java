package interf;

import java.util.Vector;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class Informations extends JPanel{

	Vector<Informations_joueur> v = new Vector<Informations_joueur>();
	JLabel tuile_a_poser;
	
}
