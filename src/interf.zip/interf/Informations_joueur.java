package interf;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class Informations_joueur extends JPanel{

	Color c;
	JLabel nom_joueur;
	JLabel nb_pions;
	JLabel nb_points;
	
}
